"""Search service business logic package."""

from .search_service import SearchService

__all__ = ["SearchService"]
