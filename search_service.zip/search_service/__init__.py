# Entry point for search_service package
